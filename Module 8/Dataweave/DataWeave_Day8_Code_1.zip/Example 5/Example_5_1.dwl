%dw 2.0
input payload application/csv header=true, separator=","
output application/json
---
payload filter ($.department == "Finance") map {
    "FirstName": $.firstName,
    "LastName": $.lastName
}