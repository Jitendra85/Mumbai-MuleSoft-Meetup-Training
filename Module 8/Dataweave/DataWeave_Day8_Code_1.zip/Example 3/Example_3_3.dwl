%dw 2.0
output application/json
---
payload filter ($.salary > 45000) map (items,idx) -> (
   items filterObject($$$ > 1) mapObject (
       (upper($$)): $
   )
)