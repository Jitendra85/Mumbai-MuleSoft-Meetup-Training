%dw 2.0
output application/json
---
payload map (items,idx) -> (
   items mapObject (
       (upper($$)): $
   )
)