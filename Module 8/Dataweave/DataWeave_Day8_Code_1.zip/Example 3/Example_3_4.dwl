%dw 2.0
output application/json
---
payload filter ($.salary > 45000) map (items,idx) -> (
   items filterObject($$$ > 0) mapObject (
       if($$ as String == "lastName"){
       (upper($$)): $,
       "STATUS": "Active"
       }else {
          (upper($$)): $ 
       }
   )
)