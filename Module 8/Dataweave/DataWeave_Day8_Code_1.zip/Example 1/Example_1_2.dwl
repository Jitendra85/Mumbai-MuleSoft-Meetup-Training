%dw 2.0
output application/json
---
{
    "ID": payload.id,
    "NAME": payload.name,
    "DEPARTMENT": payload.department,
    "SALARY": payload.salary
}