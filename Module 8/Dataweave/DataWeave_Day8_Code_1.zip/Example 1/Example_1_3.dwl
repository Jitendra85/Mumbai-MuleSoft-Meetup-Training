%dw 2.0
output application/json
---
{
    "ID": payload.id,
    "FIRSTNAME": (payload.name splitBy  " ")[0],
    "LASTNAME": (payload.name splitBy  " ")[1],
    "DEPARTMENT": payload.department,
    "SALARY": payload.salary
}