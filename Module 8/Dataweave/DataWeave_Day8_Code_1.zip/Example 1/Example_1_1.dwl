%dw 2.0
output application/xml
---
employee:payload
