%dw 2.0
import * from dw::core::Arrays
output application/json
---
{
    someEmployeeSalaryGreaterThan30000: payload..salary some ($>30000), //Syntax 1
    someEmployeeSalaryGreaterThan20000: some(payload..salary, (value) -> 
     (value > 20000)), //Syntax 2
    everyEmployeeSalaryGreaterThan30000: payload..salary every ($>30000), //Syntax 1
    everyEmployeeSalaryGreaterThan10000: every(payload..salary, (value) -> 
     (value > 10000)), //Syntax 2
     countEmployeeSalaryGreaterThan20000: payload..salary countBy ($>20000), //Syntax 1
     countEmployeeSalaryGreaterThan30000: countBy(payload..salary, (value) -> (value >30000)), //Syntax 2
     sumEmployeeSalaryGreaterThan20000: payload..salary sumBy (if($ > 20000) $ else 0), //Syntax 1
     sumEmployeeSalaryGreaterThan30000: sumBy(payload..salary, (value) -> (if(value >30000) value else 0)), //Syntax 2
}
