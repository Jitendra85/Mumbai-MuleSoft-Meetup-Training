%dw 2.0
output application/json
---
payload map {
    "ID": $.id,
    "NAME": $.name,
    "DEPARTMENT": $.department,
    "SALARY": $.salary
}