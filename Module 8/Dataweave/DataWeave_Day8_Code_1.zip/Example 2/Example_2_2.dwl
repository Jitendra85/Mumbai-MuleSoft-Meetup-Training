%dw 2.0
output application/json
---
payload filter ($.salary > 50000) map {
    "ID": $.id,
    "NAME": $.name,
    "DEPARTMENT": $.department,
    "SALARY": $.salary
}