%dw 2.0
output application/json
---
payload filter ($.salary > 50000) map (items,idx) -> {
    "INDEX": idx,
    "ID": items.id,
    "NAME": items.name,
    "DEPARTMENT": items.department,
    "SALARY": items.salary
}